import numpy as np
import requests
import json


#X={[45]}
X=45
# Serialize the data into json and send the request to the model

y_predict = requests.post('http://127.0.0.1:5000/getPredictionOutput', json={'Gender':[1], 'Height':[160], 'Weight': [45]},headers={"Content-Type": "application/json"},)
print(y_predict.json())
# Make array from the list
y_predict = np.array(y_predict.json())
print("Body Type is ", y_predict)

