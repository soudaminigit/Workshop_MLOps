import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O 
data = pd.read_csv('dataset.csv')
data_visual = pd.read_csv('dataset.csv')

def convert_status_to_description(x):
    if x['Index'] == 0:
        return 'Extremely Weak'
    elif x['Index'] == 1:
        return 'Weak'
    elif x['Index'] == 2:
        return 'Normal'
    elif x['Index'] == 3:
        return 'Overweight'
    elif x['Index']== 4:
        return 'Obesity'
    elif x['Index'] == 5:
        return 'Extreme Obesity'
data_visual['Status'] = data_visual.apply(convert_status_to_description,axis=1)


def convert_gender_to_label(x):
    if x['Gender'] == 'Male':
        return 1
    elif x['Gender'] == 'Female':
        return 0
data_visual['gender_lbl'] = data_visual.apply(convert_gender_to_label,axis=1)

from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
df = pd.DataFrame(data)

# Encode Gender
df['Gender'] = le.fit_transform(df['Gender'])
from sklearn.preprocessing import StandardScaler
# Scale the features
std_sc = StandardScaler()
df.iloc[:,0:-1] = std_sc.fit_transform(df.iloc[:,0:-1])

# Split the test and training datasets
from sklearn.model_selection import train_test_split
X = df.drop(columns=['Index'])
Y = df['Index']
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.4)

from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators=200, criterion='entropy', random_state=0)
model.fit(x_train, y_train)

y_pred_rfc = model.predict(x_test)
#print("Test Input")
#print(x_test)
#print("Test Output ")
#print(y_pred_rfc)

def predict_mpg(config, model):
    
    if type(config) == dict:
        df = pd.DataFrame(config)
    else:
        df = config
    
    y_pred = model.predict(df)
    print("Input configs")
    print(df)
    print("Weight ")
    print(df['Weight'])
    #print(y_pred)

    # Compute Accuracy
    from sklearn.metrics import accuracy_score
    rfc_acc = accuracy_score(y_test, y_pred_rfc)
    print(rfc_acc*100)

    if y_pred == 0:
        return 'Extremely Weak'
    elif y_pred == 1:
        return 'Weak'
    elif y_pred == 2:
        return 'Normal'
    elif y_pred == 3:
        return 'Overweight'
    elif y_pred == 4:
        return 'Obesity'
    elif y_pred == 5:
        return 'Extreme Obesity'

config = {
    'Gender': [1], # 1- Male, 2- Female
    'Height': [177],
    'Weight': [188]
}

config2 = {
    'Gender': [0], # 1- Male, 2- Female
    'Height': [185],
    'Weight': [110]
}

import pickle

# Save to file in the current working directory
pkl_filename = "model.pkl"
with open(pkl_filename, 'wb') as file:
    pickle.dump(model, file)

# Load from file
with open(pkl_filename, 'rb') as file:
    pickle_model = pickle.load(file)
    
# Calculate the accuracy score and predict target values
score = pickle_model.score(x_test, y_test)
print("Test score: {0:.2f} %".format(100 * score))
Ypredict = pickle_model.predict(x_test)

pkl_filename = "model.pkl"
with open(pkl_filename, 'rb') as f_in:
    model = pickle.load(f_in)

predictValue = predict_mpg(config, model)

print("Prediction 1 ")
print(predictValue)