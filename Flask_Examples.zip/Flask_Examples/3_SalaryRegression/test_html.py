import numpy as np
from flask import Flask, request, jsonify, render_template

import pickle
import urllib.request
import requests
app = Flask(__name__)
@app.route('/')
def home():

    return render_template("index.html")

@app.route('/predict',methods=['GET'])
def predict():


    '''
    For rendering results on HTML GUI
    '''
    exp = float(request.args.get('exp'))
    prediction = requests.post('http://127.0.0.1:5000/regression', json={'data':[exp]},headers={"Content-Type": "application/json"},)

    # Make array from the list
    prediction = np.array(prediction.json())
    print("Salary is", prediction)
    return render_template('index.html', prediction_text='Regression Model  has predicted salary for given experinace is : {}'.format(prediction))
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)