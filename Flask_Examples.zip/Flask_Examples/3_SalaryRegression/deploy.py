import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import urllib.request

app = Flask(__name__)
# URL of the pickle file on GitHub
url = "https://github.com/deepakmoud/Internship-Linear-regression/raw/main/linearregression.pkl"

# Download the pickle file
response = urllib.request.urlopen(url)
model = pickle.load(response)
#run_with_ngrok(app)

@app.route('/')
def home():

    return render_template("index.html")

@app.route('/predict',methods=['GET'])
def predict():


    '''
    For rendering results on HTML GUI
    '''
    exp = float(request.args.get('exp'))

    prediction = model.predict([[exp]])


    return render_template('index.html', prediction_text='Regression Model  has predicted salary for given experience is : {}'.format(prediction))


app.run()