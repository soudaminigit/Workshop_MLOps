set FLASK_APP=hello
set FLASK_ENV=development
flask run