from flask import Flask, jsonify
from flask_restful import Api, Resource, reqparse
#from flask_ngrok import run_with_ngrok

import pickle
import numpy as np
import json
# code to initiate the flask app and API.
app = Flask(__name__)
#run_with_ngrok(app)
api = Api(app)
# creates a request parser to parse arguments that will be sent with the request.
#data is sent in a JSON serialized format and name the key as data
# Create parser for the payload data
parser = reqparse.RequestParser()
parser.add_argument('data')

# Define how the api will respond to the post requests
class IrisClassifier(Resource):
    def post(self):
        args = parser.parse_args()
        X = np.array(json.loads(args['data']))
        prediction = model.predict(X)
        return jsonify(prediction.tolist())

api.add_resource(IrisClassifier, '/iris')

if __name__ == '__main__':
    # Load model

    with open('model.pickle', 'rb') as f:
        model = pickle.load(f)

    app.run()
