from flask import Flask, jsonify
from flask_restful import Api, Resource, reqparse
#from flask_ngrok import run_with_ngrok

import pickle
import numpy as np
import json
# code to initiate the flask app and API.
app = Flask(__name__)

@app.route('/iris', methods=['POST'])

def predict():
    parser = reqparse.RequestParser()
    parser.add_argument('data')
    args = parser.parse_args()
    X = np.array(json.loads(args['data']))
    prediction = model.predict(X)
    return jsonify(prediction.tolist())

@app.route('/test', methods=['GET'])

def Test():
    X= [[5.8,2.7,5.1,1.9]]
    prediction = model.predict(X)
    return jsonify(prediction.tolist())


if __name__ == '__main__':
    # Load model

    with open('model.pickle', 'rb') as f:
        model = pickle.load(f)

    app.run()
